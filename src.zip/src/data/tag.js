const tags = [
  {
    title: "Love and Betrayal",
    href: "category",
  },
  {
    title: "The Family Secrets",
    href: "category",
  },
  {
    title: "Heartbreak and Rede",
    href: "category",
  },
  {
    title: "Tragedy and Triue",
    href: "category",
  },
  {
    title: "The Coming of Age",
    href: "category",
  },
  {
    title: "Award win moves",
    href: "category",
  },
  {
    title: "Web and tv Series",
    href: "category",
  },
  {
    title: "Life in the Spotlight",
    href: "category",
  },
];

const tvShowTagsData = [
  {
    title: "The Power Strugle",
    href: "category",
  },
  {
    title: "Betrayal and Loyalty",
    href: "category",
  },
  {
    title: "Break and Redemption",
    href: "category",
  },
  {
    title: "Quest for Justice",
    href: "category",
  },
  {
    title: "The Coming of Age",
    href: "category",
  },
  {
    title: "Tragedy and Triue",
    href: "category",
  },
  {
    title: "Web and tv Series",
    href: "category",
  },
  {
    title: "Humor in Everyday",
    href: "category",
  },
];

export default tags;

export { tvShowTagsData };

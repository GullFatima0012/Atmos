import PricingList from "./PricingList";

export default function PricingTwo() {
  return (
    <div className="pricing py-80">
      <PricingList />
    </div>
  );
}
